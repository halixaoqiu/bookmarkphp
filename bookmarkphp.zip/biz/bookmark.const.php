<?php
	/**
	 * 常量集合，放各种常量
	 */
	
	define("TOKEN_NAME", "csrf_token");
	
?>