<?php
	if(empty($page_title)){
		$page_title = "草莓收藏";
	}
?>

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<title><?php echo $page_title?></title>
<link href="http://cdn.bootcss.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet">
<link href="static/bookmark.css" rel="stylesheet">
<script src="http://cdn.bootcss.com/jquery/2.1.1/jquery.min.js"></script>
<script src="http://cdn.bootcss.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>