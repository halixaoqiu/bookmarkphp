
<div class="copy">
	<span>© 2014 草莓收藏</span>
</div>
